import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { endpoint, method, headers, body } = await req.json()

    // Simulate API testing
    await new Promise(resolve => setTimeout(resolve, 1000))

    const testResult = {
      status: 200,
      responseTime: Math.floor(Math.random() * 300) + 100 + 'ms',
      headers: {
        'content-type': 'application/json',
        'x-api-version': '1.0.0',
        'x-response-time': Math.floor(Math.random() * 300) + 100 + 'ms'
      },
      data: {
        success: true,
        message: 'API endpoint is working correctly',
        timestamp: new Date().toISOString(),
        processed: true,
        results: {
          confidence: 0.95,
          predictions: [
            { class: 'positive', score: 0.85 },
            { class: 'neutral', score: 0.12 },
            { class: 'negative', score: 0.03 }
          ]
        }
      }
    }

    return new Response(
      JSON.stringify(testResult),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        error: error.message,
        status: 500,
        responseTime: '0ms'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    )
  }
})