import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    )

    const { apiId, flowData, config } = await req.json()

    // Generate deployment URL
    const deploymentUrl = `https://${apiId}.spectra-api.com`

    // Update API record with deployment info
    const { error } = await supabaseClient
      .from('apis')
      .update({
        deployed: true,
        deployment_url: deploymentUrl,
        flow_data: flowData,
        config: config,
        updated_at: new Date().toISOString()
      })
      .eq('id', apiId)

    if (error) throw error

    // Simulate API deployment process
    const deploymentResult = {
      id: apiId,
      url: deploymentUrl,
      status: 'deployed',
      endpoints: [
        {
          method: config.method || 'POST',
          path: config.path || '/process',
          description: 'Main API endpoint'
        }
      ],
      deployedAt: new Date().toISOString(),
      health: {
        status: 'healthy',
        uptime: '100%',
        responseTime: '245ms'
      }
    }

    return new Response(
      JSON.stringify(deploymentResult),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})