import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Zap,
  Database,
  Code2,
  Workflow,
  Settings,
  Home,
  ChevronDown,
  Folder,
  Plus
} from 'lucide-react';

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isProjectsOpen, setIsProjectsOpen] = useState(true);

  const menuItems = [
    { icon: <Home className="w-5 h-5" />, label: 'Dashboard', path: '/dashboard' },
    { icon: <Database className="w-5 h-5" />, label: 'Datasets', path: '/datasets' },
    { icon: <Code2 className="w-5 h-5" />, label: 'Code Builder', path: '/code-builder' },
    { icon: <Workflow className="w-5 h-5" />, label: 'API Designer', path: '/api-designer' },
    { icon: <Settings className="w-5 h-5" />, label: 'Settings', path: '/settings' }
  ];

  const projects = [
    { name: 'OCR Pipeline', active: true, onClick: () => navigate('/datasets') },
    { name: 'Support API', active: false, onClick: () => navigate('/api-designer') },
    { name: 'Code Generator', active: true, onClick: () => navigate('/code-builder') },
  ];

  const handleNewProject = () => {
    navigate('/datasets');
  };

  return (
    <motion.div
      className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col"
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Logo */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-lg flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-cyan-600 bg-clip-text text-transparent">
            Spectra AI
          </span>
        </div>
      </div>

      {/* Project Switcher */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <button
          onClick={() => setIsProjectsOpen(!isProjectsOpen)}
          className="w-full flex items-center justify-between p-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
        >
          <div className="flex items-center space-x-2">
            <Folder className="w-4 h-4" />
            <span className="font-medium">Projects</span>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              isProjectsOpen ? 'rotate-180' : ''
            }`}
          />
        </button>
        
        {isProjectsOpen && (
          <motion.div
            className="mt-2 space-y-1"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            transition={{ duration: 0.2 }}
          >
            {projects.map((project, index) => (
              <button
                key={index}
                onClick={project.onClick}
                className="w-full flex items-center space-x-2 p-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg cursor-pointer transition-colors"
              >
                <div
                  className={`w-2 h-2 rounded-full ${
                    project.active ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'
                  }`}
                />
                <span className="truncate">{project.name}</span>
              </button>
            ))}
            <button 
              onClick={handleNewProject}
              className="flex items-center space-x-2 p-2 text-sm text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg w-full"
            >
              <Plus className="w-3 h-3" />
              <span>New Project</span>
            </button>
          </motion.div>
        )}
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {menuItems.map((item, index) => {
            const isActive = location.pathname === item.path;
            return (
              <motion.button
                key={index}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600 to-cyan-600 text-white shadow-lg'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                whileHover={{ x: isActive ? 0 : 4 }}
                whileTap={{ scale: 0.98 }}
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </motion.button>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
          Spectra AI v1.0.0
        </div>
      </div>
    </motion.div>
  );
};

export default Sidebar;