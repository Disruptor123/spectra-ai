import React, { useState, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Play,
  Save,
  Settings,
  Code,
  Eye,
  Copy,
  Plus,
  Trash2,
  Database,
  Filter,
  ArrowRight,
  Globe,
  Lock,
  Zap,
  MessageSquare,
  Send,
  CheckCircle,
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import Sidebar from './dashboard/Sidebar';
import TopBar from './dashboard/TopBar';
import { useProject } from '../contexts/ProjectContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface FlowNode {
  id: string;
  type: 'input' | 'model' | 'transform' | 'output';
  subtype: string;
  label: string;
  icon: React.ReactNode;
  position: { x: number; y: number };
  connections: string[];
  config: any;
  isDragging?: boolean;
}

const APIDesigner = () => {
  const { user } = useAuth();
  const { addProject, addAPI, addActivity } = useProject();
  const [nodes, setNodes] = useState<FlowNode[]>([
    {
      id: '1',
      type: 'input',
      subtype: 'http',
      label: 'HTTP Input',
      icon: <Globe className="w-5 h-5" />,
      position: { x: 100, y: 200 },
      connections: ['2'],
      config: { method: 'POST', path: '/classify' }
    },
    {
      id: '2',
      type: 'model',
      subtype: 'classifier',
      label: 'Image Classifier',
      icon: <Zap className="w-5 h-5" />,
      position: { x: 400, y: 200 },
      connections: ['3'],
      config: { model: 'custom-classifier-v1' }
    },
    {
      id: '3',
      type: 'output',
      subtype: 'json',
      label: 'JSON Response',
      icon: <Code className="w-5 h-5" />,
      position: { x: 700, y: 200 },
      connections: [],
      config: { format: 'json', includeConfidence: true }
    }
  ]);

  const [selectedNode, setSelectedNode] = useState<string | null>('1');
  const [apiConfig, setApiConfig] = useState({
    name: 'Image Classification API',
    version: '1.0.0',
    basePath: '/api/v1',
    authentication: true,
    rateLimiting: true
  });
  const [showNodeConfig, setShowNodeConfig] = useState(false);
  const [deployedAPI, setDeployedAPI] = useState<any>(null);
  const [showAPIPreview, setShowAPIPreview] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [chatPrompt, setChatPrompt] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{role: 'user' | 'assistant', content: string}>>([]);
  const [showChat, setShowChat] = useState(false);
  const [showWebPreview, setShowWebPreview] = useState(false);
  const [dragState, setDragState] = useState<{
    isDragging: boolean;
    nodeId: string | null;
    offset: { x: number; y: number };
  }>({ isDragging: false, nodeId: null, offset: { x: 0, y: 0 } });
  const canvasRef = useRef<HTMLDivElement>(null);

  const availableNodes = {
    input: [
      { subtype: 'http', label: 'HTTP Request', icon: <Globe className="w-4 h-4" /> },
      { subtype: 'webhook', label: 'Webhook', icon: <ArrowRight className="w-4 h-4" /> },
    ],
    model: [
      { subtype: 'classifier', label: 'Classifier', icon: <Zap className="w-4 h-4" /> },
      { subtype: 'generator', label: 'Generator', icon: <Plus className="w-4 h-4" /> },
      { subtype: 'custom', label: 'Custom Model', icon: <Settings className="w-4 h-4" /> },
    ],
    transform: [
      { subtype: 'filter', label: 'Filter', icon: <Filter className="w-4 h-4" /> },
      { subtype: 'map', label: 'Transform', icon: <ArrowRight className="w-4 h-4" /> },
    ],
    output: [
      { subtype: 'json', label: 'JSON', icon: <Code className="w-4 h-4" /> },
      { subtype: 'database', label: 'Database', icon: <Database className="w-4 h-4" /> },
    ]
  };

  const handleMouseDown = (nodeId: string, event: React.MouseEvent) => {
    event.preventDefault();
    const node = nodes.find(n => n.id === nodeId);
    if (!node || !canvasRef.current) return;

    const canvasRect = canvasRef.current.getBoundingClientRect();
    const nodeRect = event.currentTarget.getBoundingClientRect();
    
    setDragState({
      isDragging: true,
      nodeId,
      offset: {
        x: event.clientX - nodeRect.left,
        y: event.clientY - nodeRect.top
      }
    });

    setNodes(prev => 
      prev.map(n => 
        n.id === nodeId ? { ...n, isDragging: true } : n
      )
    );
  };

  const handleMouseMove = useCallback((event: MouseEvent) => {
    if (!dragState.isDragging || !dragState.nodeId || !canvasRef.current) return;

    const canvasRect = canvasRef.current.getBoundingClientRect();
    const newPosition = {
      x: Math.max(0, Math.min(canvasRect.width - 120, event.clientX - canvasRect.left - dragState.offset.x)),
      y: Math.max(0, Math.min(canvasRect.height - 80, event.clientY - canvasRect.top - dragState.offset.y))
    };

    setNodes(prev => 
      prev.map(node => 
        node.id === dragState.nodeId 
          ? { ...node, position: newPosition }
          : node
      )
    );
  }, [dragState]);

  const handleMouseUp = useCallback(() => {
    if (dragState.isDragging && dragState.nodeId) {
      setNodes(prev => 
        prev.map(node => 
          node.id === dragState.nodeId 
            ? { ...node, isDragging: false }
            : node
        )
      );
    }
    setDragState({ isDragging: false, nodeId: null, offset: { x: 0, y: 0 } });
  }, [dragState]);

  React.useEffect(() => {
    if (dragState.isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [dragState.isDragging, handleMouseMove, handleMouseUp]);

  const addNode = (type: 'input' | 'model' | 'transform' | 'output', subtype: string) => {
    const nodeConfig = availableNodes[type].find(n => n.subtype === subtype);
    if (!nodeConfig) return;

    const newNode: FlowNode = {
      id: Date.now().toString(),
      type,
      subtype,
      label: nodeConfig.label,
      icon: nodeConfig.icon,
      position: { x: Math.random() * 400 + 200, y: Math.random() * 300 + 150 },
      connections: [],
      config: {}
    };

    setNodes(prev => [...prev, newNode]);
  };

  const saveFlow = async () => {
    if (!user) return;

    try {
      await addProject({
        name: apiConfig.name,
        description: `API with ${nodes.length} nodes`,
        type: 'api',
        status: 'active',
        progress: 75,
        color: 'from-blue-500 to-cyan-500',
        data: { nodes, config: apiConfig },
        config: { flowData: nodes, apiConfig }
      });

      await addActivity({
        action: 'Saved API flow',
        item: apiConfig.name
      });

      alert('API flow saved successfully!');
    } catch (error) {
      console.error('Error saving API flow:', error);
      alert('Error saving API flow. Please try again.');
    }
  };

  const testEndpoint = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('test-api', {
        body: {
          endpoint: `${apiConfig.basePath}/classify`,
          method: 'POST',
          headers: {
            'Authorization': 'Bearer test-key',
            'Content-Type': 'application/json'
          },
          body: {
            image: 'base64-encoded-image-data',
            options: { includeConfidence: true }
          }
        }
      });

      if (error) throw error;

      setTestResult(data);
    } catch (error) {
      console.error('Error testing endpoint:', error);
      setTestResult({
        status: 500,
        responseTime: '0ms',
        error: 'Failed to test endpoint'
      });
    }
  };

  const deployAPI = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase.functions.invoke('deploy-api', {
        body: {
          apiId: Date.now().toString(),
          flowData: nodes,
          config: apiConfig
        }
      });

      if (error) throw error;

      setDeployedAPI(data);
      setShowAPIPreview(true);

      // Save API to database
      await addAPI({
        name: apiConfig.name,
        endpoint: data.url,
        method: 'POST',
        deployed: true,
        config: { flowData: nodes, apiConfig }
      });

      await addActivity({
        action: 'Deployed API',
        item: apiConfig.name
      });
    } catch (error) {
      console.error('Error deploying API:', error);
      alert('Error deploying API. Please try again.');
    }
  };

  const handleChatSubmit = () => {
    if (!chatPrompt.trim()) return;

    const newMessage = { role: 'user' as const, content: chatPrompt };
    setChatHistory(prev => [...prev, newMessage]);

    // Simulate AI response
    setTimeout(() => {
      let response = '';
      if (chatPrompt.toLowerCase().includes('add') && chatPrompt.toLowerCase().includes('node')) {
        response = 'I\'ve added a new node to your API flow. The change has been applied to your visual designer.';
        addNode('model', 'generator');
      } else if (chatPrompt.toLowerCase().includes('deploy')) {
        response = 'I\'ve initiated the deployment process for your API. You can monitor the status in the preview panel.';
        deployAPI();
      } else if (chatPrompt.toLowerCase().includes('test')) {
        response = 'I\'ve run a test on your API endpoint. You can see the results in the test panel.';
        testEndpoint();
      } else if (chatPrompt.toLowerCase().includes('save')) {
        response = 'I\'ve saved your API flow. You can access it from your dashboard.';
        saveFlow();
      } else {
        response = 'I understand your request. I\'ve made the necessary changes to your API flow. The updates are now live in your visual designer.';
      }

      setChatHistory(prev => [...prev, { role: 'assistant', content: response }]);
    }, 1000);

    setChatPrompt('');
  };

  const selectedNodeData = nodes.find(n => n.id === selectedNode);

  const apiPreview = {
    request: {
      method: 'POST',
      url: '/api/v1/classify',
      headers: {
        'Authorization': 'Bearer your-api-key',
        'Content-Type': 'application/json'
      },
      body: {
        image: 'base64-encoded-image-data',
        options: {
          includeConfidence: true,
          topK: 3
        }
      }
    },
    response: {
      status: 200,
      data: {
        predictions: [
          { class: 'cat', confidence: 0.95 },
          { class: 'dog', confidence: 0.03 },
          { class: 'bird', confidence: 0.02 }
        ],
        processTime: '0.245s',
        modelVersion: 'custom-classifier-v1'
      }
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        
        <main className="flex-1 flex overflow-hidden">
          {/* Main Canvas */}
          <div className="flex-1 relative">
            {/* Toolbar */}
            <div className="absolute top-4 left-4 z-10 flex items-center space-x-2">
              <button 
                onClick={saveFlow}
                className="flex items-center space-x-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save Flow</span>
              </button>
              <button
                onClick={testEndpoint}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <Play className="w-4 h-4" />
                <span>Test Endpoint</span>
              </button>
              <button 
                onClick={deployAPI}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <Globe className="w-4 h-4" />
                <span>Deploy API</span>
              </button>
              <button
                onClick={() => setShowWebPreview(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Web Preview</span>
              </button>
              <button
                onClick={() => setShowChat(!showChat)}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
              >
                <MessageSquare className="w-4 h-4" />
                <span>AI Assistant</span>
              </button>
            </div>

            {/* Canvas */}
            <div 
              ref={canvasRef}
              className="absolute inset-0 bg-gray-100 dark:bg-gray-800"
              style={{ cursor: dragState.isDragging ? 'grabbing' : 'default' }}
            >
              {/* Grid Pattern */}
              <div 
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: `
                    radial-gradient(circle, #666 1px, transparent 1px)
                  `,
                  backgroundSize: '20px 20px'
                }}
              />
              
              {/* Connections */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                {nodes.map(node => 
                  node.connections.map(targetId => {
                    const targetNode = nodes.find(n => n.id === targetId);
                    if (!targetNode) return null;
                    
                    return (
                      <motion.path
                        key={`${node.id}-${targetId}`}
                        d={`M ${node.position.x + 120} ${node.position.y + 50} 
                           Q ${(node.position.x + targetNode.position.x) / 2 + 60} ${node.position.y + 50}
                           ${targetNode.position.x} ${targetNode.position.y + 50}`}
                        stroke="url(#apiGradient)"
                        strokeWidth="3"
                        fill="none"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 0.8 }}
                      />
                    );
                  })
                )}
                <defs>
                  <linearGradient id="apiGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#3B82F6" />
                    <stop offset="100%" stopColor="#06B6D4" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Nodes */}
              {nodes.map(node => (
                <motion.div
                  key={node.id}
                  className={`absolute w-30 h-24 bg-white dark:bg-gray-700 rounded-xl border-2 shadow-lg cursor-move transition-all duration-200 select-none ${
                    selectedNode === node.id
                      ? 'border-blue-500 shadow-blue-500/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-600'
                  } ${node.isDragging ? 'z-50 scale-110' : 'z-10'}`}
                  style={{
                    left: node.position.x,
                    top: node.position.y,
                    width: '120px',
                  }}
                  onClick={() => {
                    setSelectedNode(node.id);
                    setShowNodeConfig(true);
                  }}
                  onMouseDown={(e) => handleMouseDown(node.id, e)}
                  whileHover={{ scale: node.isDragging ? 1.1 : 1.05 }}
                  animate={{
                    scale: node.isDragging ? 1.1 : 1,
                    zIndex: node.isDragging ? 50 : 10
                  }}
                >
                  <div className="p-3 h-full flex flex-col items-center justify-center">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-2 ${
                      node.type === 'input' ? 'bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400' :
                      node.type === 'model' ? 'bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400' :
                      node.type === 'transform' ? 'bg-orange-100 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400' :
                      'bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                    }`}>
                      {node.icon}
                    </div>
                    <span className="text-xs font-medium text-gray-900 dark:text-white text-center leading-tight">
                      {node.label}
                    </span>
                  </div>
                  
                  {/* Connection Points */}
                  {node.type !== 'output' && (
                    <div className="absolute -right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full border-2 border-white dark:border-gray-700" />
                  )}
                  {node.type !== 'input' && (
                    <div className="absolute -left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full border-2 border-white dark:border-gray-700" />
                  )}
                </motion.div>
              ))}
            </div>

            {/* Chat Assistant */}
            {showChat && (
              <div className="absolute bottom-4 right-4 w-80 h-96 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 flex flex-col z-10">
                <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <h3 className="font-semibold text-gray-900 dark:text-white">AI Assistant</h3>
                  <button
                    onClick={() => setShowChat(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    ×
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {chatHistory.map((message, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg ${
                        message.role === 'user'
                          ? 'bg-purple-100 dark:bg-purple-900/20 ml-4'
                          : 'bg-gray-100 dark:bg-gray-700 mr-4'
                      }`}
                    >
                      <p className="text-sm text-gray-900 dark:text-white">{message.content}</p>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={chatPrompt}
                      onChange={(e) => setChatPrompt(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleChatSubmit()}
                      placeholder="Ask me to modify your API..."
                      className="flex-1 px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                    <button
                      onClick={handleChatSubmit}
                      className="px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Node Palette */}
          <div className="w-80 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Flow Builder
              </h2>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              {/* Input Nodes */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Input
                </h3>
                <div className="space-y-2">
                  {availableNodes.input.map(node => (
                    <button
                      key={node.subtype}
                      onClick={() => addNode('input', node.subtype)}
                      className="w-full flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors"
                    >
                      {node.icon}
                      <span className="font-medium">{node.label}</span>
                      <Plus className="w-4 h-4 ml-auto" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Model Nodes */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Models
                </h3>
                <div className="space-y-2">
                  {availableNodes.model.map(node => (
                    <button
                      key={node.subtype}
                      onClick={() => addNode('model', node.subtype)}
                      className="w-full flex items-center space-x-3 p-3 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/30 transition-colors"
                    >
                      {node.icon}
                      <span className="font-medium">{node.label}</span>
                      <Plus className="w-4 h-4 ml-auto" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Transform Nodes */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Transform
                </h3>
                <div className="space-y-2">
                  {availableNodes.transform.map(node => (
                    <button
                      key={node.subtype}
                      onClick={() => addNode('transform', node.subtype)}
                      className="w-full flex items-center space-x-3 p-3 bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300 rounded-lg hover:bg-orange-100 dark:hover:bg-orange-900/30 transition-colors"
                    >
                      {node.icon}
                      <span className="font-medium">{node.label}</span>
                      <Plus className="w-4 h-4 ml-auto" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Output Nodes */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Output
                </h3>
                <div className="space-y-2">
                  {availableNodes.output.map(node => (
                    <button
                      key={node.subtype}
                      onClick={() => addNode('output', node.subtype)}
                      className="w-full flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors"
                    >
                      {node.icon}
                      <span className="font-medium">{node.label}</span>
                      <Plus className="w-4 h-4 ml-auto" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* API Preview Panel */}
          <div className="w-96 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                API Preview
              </h2>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              {/* API Configuration */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Configuration
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">
                      API Name
                    </label>
                    <input
                      type="text"
                      value={apiConfig.name}
                      onChange={(e) => setApiConfig({ ...apiConfig, name: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700 dark:text-gray-300">Authentication</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={apiConfig.authentication}
                        onChange={(e) => setApiConfig({ ...apiConfig, authentication: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Test Results */}
              {testResult && (
                <div>
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                    Test Results
                  </h3>
                  <div className={`rounded-lg p-3 border ${
                    testResult.status === 200 
                      ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
                      : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                  }`}>
                    <div className="flex items-center space-x-2 mb-2">
                      {testResult.status === 200 ? (
                        <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                      )}
                      <span className={`text-sm font-medium ${
                        testResult.status === 200 
                          ? 'text-green-800 dark:text-green-200'
                          : 'text-red-800 dark:text-red-200'
                      }`}>
                        Status: {testResult.status} - {testResult.responseTime}
                      </span>
                    </div>
                    <pre className="text-xs text-gray-800 dark:text-gray-200 whitespace-pre-wrap overflow-x-auto">
                      {JSON.stringify(testResult.data || testResult.error, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {/* Request Preview */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Request Example
                </h3>
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-green-600 dark:text-green-400">
                      POST {apiPreview.request.url}
                    </span>
                    <button 
                      onClick={() => navigator.clipboard.writeText(JSON.stringify(apiPreview.request, null, 2))}
                      className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                  <pre className="text-xs text-gray-800 dark:text-gray-200 whitespace-pre-wrap overflow-x-auto">
                    {JSON.stringify(apiPreview.request.body, null, 2)}
                  </pre>
                </div>
              </div>

              {/* Response Preview */}
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Response Example
                </h3>
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono text-blue-600 dark:text-blue-400">
                      200 OK
                    </span>
                    <button 
                      onClick={() => navigator.clipboard.writeText(JSON.stringify(apiPreview.response, null, 2))}
                      className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                  <pre className="text-xs text-gray-800 dark:text-gray-200 whitespace-pre-wrap overflow-x-auto">
                    {JSON.stringify(apiPreview.response.data, null, 2)}
                  </pre>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <button 
                  onClick={testEndpoint}
                  className="w-full flex items-center justify-center space-x-2 p-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                >
                  <Eye className="w-4 h-4" />
                  <span>Test Endpoint</span>
                </button>
                <button 
                  onClick={deployAPI}
                  className="w-full flex items-center justify-center space-x-2 p-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                >
                  <Globe className="w-4 h-4" />
                  <span>Deploy API</span>
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Web Preview Modal */}
      {showWebPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-6xl w-full max-h-[95vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                API Web Preview - Swagger/Postman Style
              </h3>
              <button
                onClick={() => setShowWebPreview(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                ×
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[80vh]">
              <div className="space-y-6">
                {/* API Status */}
                <div className="bg-green-100 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      API Status: Live and Healthy
                    </span>
                  </div>
                  <div className="mt-2 text-sm text-green-700 dark:text-green-300">
                    <p>Uptime: 99.9% | Response Time: 245ms | Last Check: Just now</p>
                  </div>
                </div>

                {/* Endpoint Documentation */}
                <div className="bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 p-6">
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    POST /api/v1/classify
                  </h4>
                  
                  <div className="space-y-4">
                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Description</h5>
                      <p className="text-gray-600 dark:text-gray-400">
                        Classify images using AI model with confidence scores
                      </p>
                    </div>

                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Headers</h5>
                      <div className="bg-gray-50 dark:bg-gray-800 rounded p-3">
                        <code className="text-sm">
                          Authorization: Bearer your-api-key<br/>
                          Content-Type: application/json
                        </code>
                      </div>
                    </div>

                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Request Body</h5>
                      <div className="bg-gray-50 dark:bg-gray-800 rounded p-3">
                        <pre className="text-sm text-gray-800 dark:text-gray-200">
{JSON.stringify({
  image: "base64-encoded-image-data",
  options: {
    includeConfidence: true,
    topK: 3
  }
}, null, 2)}
                        </pre>
                      </div>
                    </div>

                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Response</h5>
                      <div className="bg-gray-50 dark:bg-gray-800 rounded p-3">
                        <pre className="text-sm text-gray-800 dark:text-gray-200">
{JSON.stringify({
  predictions: [
    { class: "cat", confidence: 0.95 },
    { class: "dog", confidence: 0.03 },
    { class: "bird", confidence: 0.02 }
  ],
  processTime: "0.245s",
  modelVersion: "custom-classifier-v1"
}, null, 2)}
                        </pre>
                      </div>
                    </div>

                    <div>
                      <h5 className="font-medium text-gray-900 dark:text-white mb-2">Try It Out</h5>
                      <div className="space-y-3">
                        <textarea
                          placeholder="Paste your request body here..."
                          className="w-full h-32 px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        />
                        <button
                          onClick={testEndpoint}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          Execute Request
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Performance Metrics */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 p-4 text-center">
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">99.9%</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Uptime</div>
                  </div>
                  <div className="bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">245ms</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Avg Response</div>
                  </div>
                  <div className="bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 p-4 text-center">
                    <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">1.2K</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">Requests/day</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Node Configuration Modal */}
      {showNodeConfig && selectedNodeData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                Configure {selectedNodeData.label}
              </h3>
              <button
                onClick={() => setShowNodeConfig(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                ×
              </button>
            </div>
            <div className="p-6">
              {selectedNodeData.type === 'input' && selectedNodeData.subtype === 'http' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      HTTP Method
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                      <option>POST</option>
                      <option>GET</option>
                      <option>PUT</option>
                      <option>DELETE</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Route Path
                    </label>
                    <input
                      type="text"
                      defaultValue="/classify"
                      className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
              )}
              
              {selectedNodeData.type === 'model' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Model Type
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                      <option>Image Classifier</option>
                      <option>Text Generator</option>
                      <option>Custom Model</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Model Version
                    </label>
                    <input
                      type="text"
                      defaultValue="v1.0.0"
                      className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* API Preview Modal */}
      {showAPIPreview && deployedAPI && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                API Deployed Successfully
              </h3>
              <button
                onClick={() => setShowAPIPreview(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                ×
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[70vh]">
              <div className="space-y-6">
                <div className="bg-green-100 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      Your API is now live and ready to use!
                    </span>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white mb-3">API Details</h4>
                    <div className="space-y-2 text-sm">
                      <div><strong>Name:</strong> {deployedAPI.name || apiConfig.name}</div>
                      <div><strong>URL:</strong> {deployedAPI.url}</div>
                      <div><strong>Version:</strong> {deployedAPI.version || apiConfig.version}</div>
                      <div><strong>Status:</strong> <span className="text-green-600">Live</span></div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white mb-3">Endpoints</h4>
                    <div className="space-y-2">
                      {deployedAPI.endpoints?.map((endpoint: any, index: number) => (
                        <div key={index} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                          <div className="font-mono text-sm">
                            <span className="text-blue-600 dark:text-blue-400">{endpoint.method}</span> {endpoint.path}
                          </div>
                          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                            {endpoint.description}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-3">Integration Code</h4>
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <pre className="text-sm text-gray-800 dark:text-gray-200 overflow-x-auto">
{`// JavaScript/Node.js
const response = await fetch('${deployedAPI.url}/classify', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    image: 'base64-encoded-image-data',
    options: { includeConfidence: true }
  })
});

const result = await response.json();
console.log(result);`}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default APIDesigner;