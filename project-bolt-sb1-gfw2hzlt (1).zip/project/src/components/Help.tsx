import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Book,
  Database,
  Workflow,
  Code2,
  Search,
  ChevronRight,
  Play,
  Upload,
  Download,
  Settings,
  Zap,
  CheckCircle,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import Sidebar from './dashboard/Sidebar';
import TopBar from './dashboard/TopBar';

const Help = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const sections = [
    {
      id: 'overview',
      title: 'Getting Started',
      icon: <Book className="w-5 h-5" />,
      content: {
        title: 'Welcome to Spectra AI',
        description: 'Your comprehensive guide to transforming data into intelligence',
        steps: [
          {
            title: 'Create Your Account',
            description: 'Sign up and access your personalized dashboard',
            icon: <CheckCircle className="w-5 h-5 text-green-500" />
          },
          {
            title: 'Choose Your Workflow',
            description: 'Select from Dataset Transformation, API Design, or Code Generation',
            icon: <Workflow className="w-5 h-5 text-blue-500" />
          },
          {
            title: 'Build and Deploy',
            description: 'Use our visual tools to create production-ready solutions',
            icon: <Zap className="w-5 h-5 text-purple-500" />
          }
        ]
      }
    },
    {
      id: 'datasets',
      title: 'Dataset Transformation',
      icon: <Database className="w-5 h-5" />,
      content: {
        title: 'Transform Unstructured Data into AI-Ready Datasets',
        description: 'Learn how to use our visual drag-and-drop interface to process your data',
        steps: [
          {
            title: 'Upload Your Data',
            description: 'Drag and drop images, audio, text, JSON, or CSV files into input nodes',
            details: [
              'Support for multiple file formats: images (JPG, PNG, GIF), audio (MP3, WAV), text files, JSON, CSV',
              'Batch upload multiple files at once',
              'Real-time file validation and preview'
            ]
          },
          {
            title: 'Configure AI Processors',
            description: 'Add OCR, audio-to-text, or image segmentation processors',
            details: [
              'OCR: Extract text from images with high accuracy',
              'Audio-to-Text: Convert speech to text with timestamps',
              'Image Segmentation: Identify and separate objects in images',
              'Custom processing options for specific use cases'
            ]
          },
          {
            title: 'Set Output Format',
            description: 'Choose JSON or CSV output with training-ready structure',
            details: [
              'Training-ready format compatible with TensorFlow, PyTorch, Hugging Face',
              'Includes confidence scores and metadata',
              'Validation and test splits automatically configured',
              'Schema documentation for easy integration'
            ]
          },
          {
            title: 'Run and Export',
            description: 'Process your data and export the structured dataset',
            details: [
              'Real-time processing with progress indicators',
              'Quality validation and error checking',
              'Export in multiple formats for different ML frameworks',
              'Automatic backup and version control'
            ]
          }
        ]
      }
    },
    {
      id: 'api-designer',
      title: 'API Designer',
      icon: <Workflow className="w-5 h-5" />,
      content: {
        title: 'Build APIs with Visual Flowcharts',
        description: 'Create and deploy production-ready APIs without writing code',
        steps: [
          {
            title: 'Design Your Flow',
            description: 'Drag and drop components to create your API workflow',
            details: [
              'HTTP Input: Configure endpoints, methods, and parameters',
              'Webhooks: Automatic webhook generation for real-time events',
              'Models: Integrate classifiers, generators, or custom AI models',
              'Transforms: Add filters and data transformation logic'
            ]
          },
          {
            title: 'Configure Components',
            description: 'Set up each component with specific parameters',
            details: [
              'HTTP methods: GET, POST, PUT, DELETE support',
              'Authentication: API key, OAuth, or custom auth',
              'Rate limiting: Configure request limits and throttling',
              'Error handling: Custom error responses and logging'
            ]
          },
          {
            title: 'Test Your API',
            description: 'Use the built-in testing tools to validate functionality',
            details: [
              'Interactive API testing interface (like Postman)',
              'Real-time response preview',
              'Performance metrics and latency monitoring',
              'Error debugging and troubleshooting tools'
            ]
          },
          {
            title: 'Deploy and Monitor',
            description: 'Deploy to production and monitor performance',
            details: [
              'One-click deployment to cloud infrastructure',
              'Automatic scaling and load balancing',
              'Real-time monitoring and analytics',
              'API documentation generation'
            ]
          }
        ]
      }
    },
    {
      id: 'code-builder',
      title: 'Code Builder',
      icon: <Code2 className="w-5 h-5" />,
      content: {
        title: 'Generate Code from Sketches and Ideas',
        description: 'Transform your concepts into functional websites and applications',
        steps: [
          {
            title: 'Upload Your Input',
            description: 'Choose from sketches, pseudocode, or diagrams',
            details: [
              'Sketches: Hand-drawn UI mockups and wireframes',
              'Pseudocode: Written logic and algorithm descriptions',
              'Diagrams: Flowcharts and system architecture diagrams',
              'Support for multiple image formats and text files'
            ]
          },
          {
            title: 'Add Context',
            description: 'Provide detailed instructions for code generation',
            details: [
              'Describe the desired functionality and features',
              'Specify technology preferences (React, Vue, etc.)',
              'Include design requirements and styling preferences',
              'Add any specific constraints or requirements'
            ]
          },
          {
            title: 'Generate Code',
            description: 'AI creates production-ready code based on your input',
            details: [
              'Full-stack web applications with modern frameworks',
              'Responsive design with mobile optimization',
              'Clean, maintainable code with best practices',
              'Integrated styling with CSS frameworks'
            ]
          },
          {
            title: 'Preview and Export',
            description: 'Test your application and export the code',
            details: [
              'Live preview with interactive functionality',
              'Code editor with syntax highlighting',
              'Export as complete project files',
              'Integration with version control systems'
            ]
          }
        ]
      }
    }
  ];

  const faqs = [
    {
      question: 'How accurate is the AI processing?',
      answer: 'Our AI models achieve 95%+ accuracy for OCR, 92%+ for audio transcription, and 90%+ for image segmentation. Accuracy varies based on input quality and complexity.'
    },
    {
      question: 'What file formats are supported?',
      answer: 'We support images (JPG, PNG, GIF, WebP), audio (MP3, WAV, M4A), text files (TXT, MD), structured data (JSON, CSV), and documents (PDF coming soon).'
    },
    {
      question: 'Can I use the generated datasets for commercial projects?',
      answer: 'Yes, all datasets and code generated through Spectra AI are yours to use commercially. We don\'t claim any rights to your processed data or generated content.'
    },
    {
      question: 'How do I integrate with existing ML pipelines?',
      answer: 'Our datasets are compatible with TensorFlow, PyTorch, and Hugging Face. We provide detailed integration guides and example code for each framework.'
    },
    {
      question: 'Is my data secure?',
      answer: 'Yes, we use enterprise-grade encryption for data in transit and at rest. Your data is never shared with third parties and is automatically deleted after processing unless you choose to save it.'
    }
  ];

  const filteredSections = sections.filter(section =>
    section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.content.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentSection = sections.find(s => s.id === activeSection);

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        
        <main className="flex-1 flex overflow-hidden">
          {/* Sidebar */}
          <div className="w-80 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Help & Documentation
              </h2>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search documentation..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto p-4">
              <div className="space-y-2">
                {filteredSections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                      activeSection === section.id
                        ? 'bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    {section.icon}
                    <span className="font-medium">{section.title}</span>
                    <ChevronRight className="w-4 h-4 ml-auto" />
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Quick Links
                </h3>
                <div className="space-y-2">
                  <a
                    href="#"
                    className="flex items-center space-x-2 text-sm text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>API Reference</span>
                  </a>
                  <a
                    href="#"
                    className="flex items-center space-x-2 text-sm text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Video Tutorials</span>
                  </a>
                  <a
                    href="#"
                    className="flex items-center space-x-2 text-sm text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Community Forum</span>
                  </a>
                </div>
              </div>
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto">
            {currentSection && (
              <div className="p-8 max-w-4xl">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                      {currentSection.content.title}
                    </h1>
                    <p className="text-lg text-gray-600 dark:text-gray-400">
                      {currentSection.content.description}
                    </p>
                  </div>

                  {currentSection.id === 'overview' ? (
                    <div className="grid md:grid-cols-3 gap-6 mb-8">
                      {currentSection.content.steps.map((step, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: index * 0.1 }}
                          className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6"
                        >
                          <div className="flex items-center space-x-3 mb-4">
                            {step.icon}
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                              {step.title}
                            </h3>
                          </div>
                          <p className="text-gray-600 dark:text-gray-400">
                            {step.description}
                          </p>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-8">
                      {currentSection.content.steps.map((step, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: index * 0.1 }}
                          className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6"
                        >
                          <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0 w-8 h-8 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center">
                              <span className="text-sm font-semibold text-purple-600 dark:text-purple-400">
                                {index + 1}
                              </span>
                            </div>
                            <div className="flex-1">
                              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                                {step.title}
                              </h3>
                              <p className="text-gray-600 dark:text-gray-400 mb-4">
                                {step.description}
                              </p>
                              {step.details && (
                                <ul className="space-y-2">
                                  {step.details.map((detail, detailIndex) => (
                                    <li key={detailIndex} className="flex items-start space-x-2">
                                      <ArrowRight className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                                      <span className="text-sm text-gray-700 dark:text-gray-300">
                                        {detail}
                                      </span>
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* FAQ Section */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                    className="mt-12"
                  >
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                      Frequently Asked Questions
                    </h2>
                    <div className="space-y-4">
                      {faqs.map((faq, index) => (
                        <div
                          key={index}
                          className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6"
                        >
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                            {faq.question}
                          </h3>
                          <p className="text-gray-600 dark:text-gray-400">
                            {faq.answer}
                          </p>
                        </div>
                      ))}
                    </div>
                  </motion.div>

                  {/* Contact Support */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.6 }}
                    className="mt-12 bg-gradient-to-r from-purple-50 to-cyan-50 dark:from-purple-900/20 dark:to-cyan-900/20 rounded-lg border border-purple-200 dark:border-purple-800 p-6"
                  >
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      Need More Help?
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Can't find what you're looking for? Our support team is here to help.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                        Contact Support
                      </button>
                      <button className="px-4 py-2 border border-purple-600 text-purple-600 dark:text-purple-400 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-colors">
                        Schedule Demo
                      </button>
                    </div>
                  </motion.div>
                </motion.div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Help;