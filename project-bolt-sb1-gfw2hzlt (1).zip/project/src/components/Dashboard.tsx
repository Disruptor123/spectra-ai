import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  Database,
  Code2,
  Workflow,
  Settings,
  Bell,
  Search,
  Plus,
  BarChart3,
  Zap,
  Users,
  Activity,
  TrendingUp,
  Folder,
  Clock
} from 'lucide-react';
import Sidebar from './dashboard/Sidebar';
import TopBar from './dashboard/TopBar';
import ProjectCard from './dashboard/ProjectCard';
import StatCard from './dashboard/StatCard';
import { useProject } from '../contexts/ProjectContext';

const Dashboard = () => {
  const navigate = useNavigate();
  const { projects, stats, activities, isLoading } = useProject();
  const [selectedProject, setSelectedProject] = useState<string | null>(null);

  const statsData = [
    { 
      label: 'Active Projects', 
      value: stats.projectsCreated.toString(), 
      icon: <Folder className="w-5 h-5" />, 
      trend: stats.projectsCreated > 0 ? `+${stats.projectsCreated} created` : 'No projects yet' 
    },
    { 
      label: 'Datasets Processed', 
      value: stats.datasetsProcessed.toString(), 
      icon: <Database className="w-5 h-5" />, 
      trend: stats.datasetsProcessed > 0 ? `+${stats.datasetsProcessed} processed` : 'No datasets yet' 
    },
    { 
      label: 'APIs Deployed', 
      value: stats.apisDeployed.toString(), 
      icon: <Activity className="w-5 h-5" />, 
      trend: stats.apisDeployed > 0 ? `+${stats.apisDeployed} deployed` : 'No APIs yet' 
    },
    { 
      label: 'Model Accuracy', 
      value: stats.modelAccuracy > 0 ? `${stats.modelAccuracy}%` : '0%', 
      icon: <TrendingUp className="w-5 h-5" />, 
      trend: stats.modelAccuracy > 0 ? `${stats.modelAccuracy}% average` : 'No models yet' 
    }
  ];

  const handleNewProject = () => {
    navigate('/datasets');
  };

  const handleActivityClick = (activity: any) => {
    if (activity.projectId) {
      // Navigate to the specific project
      const project = projects.find(p => p.id === activity.projectId);
      if (project) {
        switch (project.type) {
          case 'dataset':
            navigate('/datasets');
            break;
          case 'api':
            navigate('/api-designer');
            break;
          case 'code':
            navigate('/code-builder');
            break;
          default:
            navigate('/dashboard');
        }
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <TopBar />
          <main className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <motion.div
                className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full mx-auto mb-4"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              />
              <p className="text-gray-600 dark:text-gray-400">Loading your dashboard...</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-8">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                  Dashboard
                </h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  Welcome back! Here's what's happening with your projects.
                </p>
              </motion.div>
              
              <motion.div
                className="flex items-center gap-3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <Search className="w-4 h-4" />
                  <span className="hidden sm:inline">Search</span>
                </button>
                <button 
                  onClick={handleNewProject}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                >
                  <Plus className="w-4 h-4" />
                  <span>New Project</span>
                </button>
              </motion.div>
            </div>

            {/* Stats Grid */}
            <motion.div
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {statsData.map((stat, index) => (
                <StatCard key={index} {...stat} />
              ))}
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <button
                onClick={() => navigate('/datasets')}
                className="group p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600 hover:shadow-lg transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    <Database className="w-6 h-6" />
                  </div>
                  <motion.div
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    whileHover={{ x: 5 }}
                  >
                    →
                  </motion.div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Transform Data
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Upload and transform unstructured data into training datasets
                </p>
              </button>

              <button
                onClick={() => navigate('/api-designer')}
                className="group p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-600 hover:shadow-lg transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    <Workflow className="w-6 h-6" />
                  </div>
                  <motion.div
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    whileHover={{ x: 5 }}
                  >
                    →
                  </motion.div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Design APIs
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Create and deploy custom APIs with visual flowcharts
                </p>
              </button>

              <button 
                onClick={() => navigate('/code-builder')}
                className="group p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-green-300 dark:hover:border-green-600 hover:shadow-lg transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    <Code2 className="w-6 h-6" />
                  </div>
                  <motion.div
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    whileHover={{ x: 5 }}
                  >
                    →
                  </motion.div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Generate Code
                </h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Transform pseudocode and diagrams into production code
                </p>
              </button>
            </motion.div>

            {/* Projects and Recent Activity */}
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Projects */}
              <motion.div
                className="lg:col-span-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                    Your Projects
                  </h2>
                  {projects.length > 0 && (
                    <button className="text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300 font-medium">
                      View All
                    </button>
                  )}
                </div>
                
                {projects.length === 0 ? (
                  <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700">
                    <Folder className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                      No projects yet
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">
                      Create your first project to get started with Spectra AI
                    </p>
                    <button
                      onClick={handleNewProject}
                      className="px-6 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                    >
                      Create Project
                    </button>
                  </div>
                ) : (
                  <div className="grid gap-6">
                    {projects.slice(0, 4).map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        isSelected={selectedProject === project.id}
                        onClick={() => setSelectedProject(project.id)}
                      />
                    ))}
                  </div>
                )}
              </motion.div>

              {/* Recent Activity */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
                className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 h-fit"
              >
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Recent Activity
                </h2>
                <div className="space-y-4">
                  {activities.length === 0 ? (
                    <div className="text-center py-8">
                      <Clock className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-500 dark:text-gray-400 text-sm">
                        No recent activity
                      </p>
                    </div>
                  ) : (
                    activities.map((activity, index) => (
                      <button
                        key={index}
                        onClick={() => handleActivityClick(activity)}
                        className="w-full flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors text-left"
                      >
                        <div className="w-2 h-2 bg-purple-500 rounded-full flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-gray-900 dark:text-white">
                            <span className="font-medium">{activity.action}</span> {activity.item}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {new Date(activity.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </motion.div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;