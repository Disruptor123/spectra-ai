import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Upload,
  Play,
  Download,
  Plus,
  Trash2,
  Settings,
  Eye,
  Image,
  FileText,
  Music,
  Database,
  Brain,
  Zap,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  Code,
  Wand2,
  Copy,
  Save,
  MessageSquare,
  Send
} from 'lucide-react';
import Sidebar from './dashboard/Sidebar';
import TopBar from './dashboard/TopBar';

const CodeBuilder = () => {
  const [activeTab, setActiveTab] = useState<'sketch' | 'pseudocode' | 'diagram'>('sketch');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [promptText, setPromptText] = useState('');
  const [pseudocode, setPseudocode] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [previewContent, setPreviewContent] = useState('');
  const [chatPrompt, setChatPrompt] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{role: 'user' | 'assistant', content: string}>>([]);
  const [showChat, setShowChat] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const generateLandingPageCode = (type: string, prompt: string) => {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${prompt || 'Generated Landing Page'}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeInUp { animation: fadeInUp 0.6s ease-out; }
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-50">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg"></div>
                    <span class="text-xl font-bold text-gray-800">${prompt.split(' ')[0] || 'Brand'}</span>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="#home" class="text-gray-600 hover:text-purple-600 transition-colors">Home</a>
                    <a href="#features" class="text-gray-600 hover:text-purple-600 transition-colors">Features</a>
                    <a href="#about" class="text-gray-600 hover:text-purple-600 transition-colors">About</a>
                    <a href="#contact" class="text-gray-600 hover:text-purple-600 transition-colors">Contact</a>
                </div>
                <button class="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all">
                    Get Started
                </button>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="gradient-bg min-h-screen flex items-center justify-center text-white pt-20">
        <div class="max-w-4xl mx-auto text-center px-4">
            <h1 class="text-5xl md:text-6xl font-bold mb-6 animate-fadeInUp">
                ${prompt || 'Welcome to Our Platform'}
            </h1>
            <p class="text-xl md:text-2xl mb-8 opacity-90 animate-fadeInUp" style="animation-delay: 0.2s;">
                Transform your ideas into reality with our innovative solutions
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center animate-fadeInUp" style="animation-delay: 0.4s;">
                <button class="bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:shadow-lg transition-all">
                    Start Free Trial
                </button>
                <button class="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-purple-600 transition-all">
                    Learn More
                </button>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">Amazing Features</h2>
                <p class="text-xl text-gray-600">Discover what makes us different</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center p-6 rounded-lg hover:shadow-lg transition-all">
                    <div class="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Fast Performance</h3>
                    <p class="text-gray-600">Lightning-fast performance that scales with your needs</p>
                </div>
                <div class="text-center p-6 rounded-lg hover:shadow-lg transition-all">
                    <div class="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Reliable</h3>
                    <p class="text-gray-600">99.9% uptime guarantee with enterprise-grade security</p>
                </div>
                <div class="text-center p-6 rounded-lg hover:shadow-lg transition-all">
                    <div class="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">User Friendly</h3>
                    <p class="text-gray-600">Intuitive interface designed for maximum productivity</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 gradient-bg text-white">
        <div class="max-w-4xl mx-auto text-center px-4">
            <h2 class="text-4xl font-bold mb-4">Ready to Get Started?</h2>
            <p class="text-xl mb-8 opacity-90">Join thousands of satisfied customers today</p>
            <button class="bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:shadow-lg transition-all text-lg">
                Start Your Journey
            </button>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg"></div>
                        <span class="text-xl font-bold">${prompt.split(' ')[0] || 'Brand'}</span>
                    </div>
                    <p class="text-gray-400">Building the future, one innovation at a time.</p>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Product</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="#" class="hover:text-white transition-colors">Features</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Pricing</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Documentation</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Company</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="#" class="hover:text-white transition-colors">About</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Blog</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Careers</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Support</h4>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="#" class="hover:text-white transition-colors">Help Center</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Contact</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Status</a></li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; 2024 ${prompt.split(' ')[0] || 'Brand'}. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add scroll animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        document.querySelectorAll('section').forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(30px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(section);
        });
    </script>
</body>
</html>`;
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    
    // Simulate code generation based on input type
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    let code = '';
    let preview = '';
    
    if (activeTab === 'sketch' && uploadedFile) {
      // Generate landing page code based on sketch and prompt
      code = generateLandingPageCode('sketch', promptText);
      preview = code;
    } else if (activeTab === 'pseudocode' && pseudocode) {
      // Generate landing page code based on pseudocode
      code = generateLandingPageCode('pseudocode', pseudocode.split('\n')[0] || 'Generated Website');
      preview = code;
    } else if (activeTab === 'diagram' && uploadedFile) {
      // Generate landing page code based on diagram
      code = generateLandingPageCode('diagram', promptText);
      preview = code;
    }
    
    setGeneratedCode(code);
    setPreviewContent(preview);
    setIsGenerating(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
  };

  const saveCode = () => {
    const blob = new Blob([generatedCode], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${activeTab}-website.html`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportCode = () => {
    const blob = new Blob([generatedCode], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `generated-website.html`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleChatSubmit = () => {
    if (!chatPrompt.trim()) return;

    const newMessage = { role: 'user' as const, content: chatPrompt };
    setChatHistory(prev => [...prev, newMessage]);

    // Simulate AI response
    setTimeout(() => {
      let response = '';
      if (chatPrompt.toLowerCase().includes('color')) {
        response = 'I\'ve updated the color scheme of your website. The changes have been applied to the generated code.';
        // Update the generated code with new colors
        const updatedCode = generatedCode.replace(/purple-600/g, 'blue-600').replace(/purple-500/g, 'blue-500');
        setGeneratedCode(updatedCode);
        setPreviewContent(updatedCode);
      } else if (chatPrompt.toLowerCase().includes('layout')) {
        response = 'I\'ve modified the layout structure as requested. Your website design has been updated.';
      } else if (chatPrompt.toLowerCase().includes('add')) {
        response = 'I\'ve added the requested component to your website. You can see the changes in the preview.';
      } else {
        response = 'I understand your request. I\'ve made the necessary changes to your website code. You can see the updates in the code editor and preview.';
      }

      setChatHistory(prev => [...prev, { role: 'assistant', content: response }]);
    }, 1000);

    setChatPrompt('');
  };

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        
        <main className="flex-1 flex overflow-hidden">
          {/* Input Panel */}
          <div className="flex-1 flex flex-col">
            {/* Toolbar */}
            <div className="p-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                    Code Builder
                  </h1>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setActiveTab('sketch')}
                      className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                        activeTab === 'sketch'
                          ? 'bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      <Image className="w-4 h-4 inline mr-1" />
                      Sketch
                    </button>
                    <button
                      onClick={() => setActiveTab('pseudocode')}
                      className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                        activeTab === 'pseudocode'
                          ? 'bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      <FileText className="w-4 h-4 inline mr-1" />
                      Pseudocode
                    </button>
                    <button
                      onClick={() => setActiveTab('diagram')}
                      className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                        activeTab === 'diagram'
                          ? 'bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      <Code className="w-4 h-4 inline mr-1" />
                      Diagram
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating || (!uploadedFile && !pseudocode)}
                    className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 text-white rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Wand2 className="w-4 h-4" />
                    <span>{isGenerating ? 'Generating...' : 'Generate Code'}</span>
                  </button>
                  <button
                    onClick={() => setShowChat(!showChat)}
                    className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>AI Assistant</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Input Area */}
            <div className="flex-1 p-6">
              {activeTab === 'sketch' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full space-y-4"
                >
                  <div className="h-2/3 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center bg-gray-50 dark:bg-gray-800">
                    {uploadedFile ? (
                      <div className="text-center">
                        <Image className="w-16 h-16 text-green-500 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                          {uploadedFile.name}
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400">
                          Sketch uploaded successfully
                        </p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Image className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                          Upload a Sketch or Drawing
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          Draw your UI mockup or upload an image of your hand-drawn design
                        </p>
                        <label className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors cursor-pointer">
                          Choose File
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                        </label>
                      </div>
                    )}
                  </div>
                  <div className="h-1/3">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Describe what you want to build
                    </label>
                    <textarea
                      value={promptText}
                      onChange={(e) => setPromptText(e.target.value)}
                      className="w-full h-full p-4 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Describe how you want your sketch to be implemented as a landing page..."
                    />
                  </div>
                </motion.div>
              )}

              {activeTab === 'pseudocode' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full"
                >
                  <textarea
                    value={pseudocode}
                    onChange={(e) => setPseudocode(e.target.value)}
                    className="w-full h-full p-4 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Write your pseudocode here...

Example:
1. Create a modern landing page for a tech startup
2. Add a hero section with call-to-action buttons
3. Include a features section with 3 columns
4. Add a contact form in the footer
5. Use purple and blue gradient colors
6. Make it responsive and animated"
                  />
                </motion.div>
              )}

              {activeTab === 'diagram' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="h-full space-y-4"
                >
                  <div className="h-2/3 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex items-center justify-center bg-gray-50 dark:bg-gray-800">
                    {uploadedFile ? (
                      <div className="text-center">
                        <Code className="w-16 h-16 text-green-500 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                          {uploadedFile.name}
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400">
                          Diagram uploaded successfully
                        </p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Code className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                          Upload a Flowchart or Diagram
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          Upload an image of your system architecture or flow diagram
                        </p>
                        <label className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors cursor-pointer">
                          Choose File
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                        </label>
                      </div>
                    )}
                  </div>
                  <div className="h-1/3">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Describe your diagram implementation
                    </label>
                    <textarea
                      value={promptText}
                      onChange={(e) => setPromptText(e.target.value)}
                      className="w-full h-full p-4 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Describe how you want your diagram to be implemented as a website..."
                    />
                  </div>
                </motion.div>
              )}
            </div>

            {/* Chat Assistant */}
            {showChat && (
              <div className="absolute bottom-4 right-4 w-80 h-96 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 flex flex-col z-10">
                <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <h3 className="font-semibold text-gray-900 dark:text-white">AI Assistant</h3>
                  <button
                    onClick={() => setShowChat(false)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    ×
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {chatHistory.map((message, index) => (
                    <div
                      key={index}
                      className={`p-3 rounded-lg ${
                        message.role === 'user'
                          ? 'bg-purple-100 dark:bg-purple-900/20 ml-4'
                          : 'bg-gray-100 dark:bg-gray-700 mr-4'
                      }`}
                    >
                      <p className="text-sm text-gray-900 dark:text-white">{message.content}</p>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={chatPrompt}
                      onChange={(e) => setChatPrompt(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleChatSubmit()}
                      placeholder="Ask me to modify your code..."
                      className="flex-1 px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                    <button
                      onClick={handleChatSubmit}
                      className="px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Output Panel */}
          <div className="w-1/2 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Generated Code
                </h2>
                <div className="flex items-center space-x-2">
                  {generatedCode && (
                    <button
                      onClick={() => setShowPreview(true)}
                      className="flex items-center space-x-1 px-3 py-1 text-sm bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-lg hover:bg-green-200 dark:hover:bg-green-900/30 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Preview</span>
                    </button>
                  )}
                  <button
                    onClick={copyToClipboard}
                    disabled={!generatedCode}
                    className="flex items-center space-x-1 px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Copy className="w-4 h-4" />
                    <span>Copy</span>
                  </button>
                  <button
                    onClick={saveCode}
                    disabled={!generatedCode}
                    className="flex items-center space-x-1 px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                  <button
                    onClick={exportCode}
                    disabled={!generatedCode}
                    className="flex items-center space-x-1 px-3 py-1 text-sm bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-hidden">
              {isGenerating ? (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center">
                    <motion.div
                      className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full mx-auto mb-4"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    />
                    <p className="text-gray-600 dark:text-gray-400">
                      Generating stunning landing page from your input...
                    </p>
                  </div>
                </div>
              ) : generatedCode ? (
                <div className="h-full overflow-auto">
                  <pre className="p-4 text-sm text-gray-800 dark:text-gray-200 font-mono leading-relaxed">
                    <code>{generatedCode}</code>
                  </pre>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center">
                    <Zap className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">
                      Your generated landing page code will appear here
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-7xl w-full max-h-[95vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                Website Preview - Fully Functional
              </h3>
              <button
                onClick={() => setShowPreview(false)}
                className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                ×
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[80vh]">
              <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                <div className="mb-4 p-4 bg-green-100 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      Fully functional landing page generated and ready for deployment
                    </span>
                  </div>
                </div>
                <iframe
                  srcDoc={previewContent}
                  className="w-full h-96 border border-gray-200 dark:border-gray-600 rounded-lg"
                  title="Website Preview"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CodeBuilder;