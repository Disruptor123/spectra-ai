import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  Zap, 
  Layers3, 
  Workflow, 
  Database, 
  Brain, 
  Code2, 
  ArrowRight,
  Moon,
  Sun,
  Menu,
  X,
  Users,
  Rocket,
  FlaskConical,
  Building,
  FileText,
  BookOpen,
  Grid3X3
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import AuthModal from './AuthModal';

const LandingPage = () => {
  const { isDark, toggleTheme } = useTheme();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const openAuthModal = (mode: 'signin' | 'signup') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const navigationItems = [
    { label: 'Product', href: '#product' },
    { label: 'Features', href: '#features' },
    { label: 'Documentation', href: '#docs' },
    { label: 'Blog', href: '#blog' },
    { label: 'Ecosystem', href: '#ecosystem' }
  ];

  const features = [
    {
      icon: <Layers3 className="w-8 h-8" />,
      title: "3D Visual Data Transform",
      description: "Transform unstructured data into structured datasets with our intuitive 3D canvas interface"
    },
    {
      icon: <Workflow className="w-8 h-8" />,
      title: "No-Code API Designer",
      description: "Create and deploy custom APIs by drawing flowcharts - no coding required"
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI Model Training",
      description: "Train custom AI models like DALL·E and LLaMA with your structured datasets"
    },
    {
      icon: <Code2 className="w-8 h-8" />,
      title: "Visual Code Generation",
      description: "Transform pseudocode and diagrams into production-ready code"
    }
  ];

  const userTypes = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: "AI Engineers",
      description: "Speed up dataset prep, model training, and prototyping."
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "No-Code Creators",
      description: "Build powerful AI workflows without touching code."
    },
    {
      icon: <FlaskConical className="w-6 h-6" />,
      title: "Researchers & Data Scientists",
      description: "Tame messy data with visual structure."
    },
    {
      icon: <Building className="w-6 h-6" />,
      title: "Startups & Hackers",
      description: "Go from zero to AI product visually."
    }
  ];

  const dashboardPreviews = [
    {
      title: "3D Dataset Transformer",
      description: "Visual drag-and-drop interface for data transformation",
      image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "No-Code API Designer",
      description: "Build APIs with flowcharts and deploy instantly",
      image: "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      title: "AI Model Training Hub",
      description: "Train custom models with structured datasets",
      image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=800"
    }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      {/* Animated Background - Black with Purple accents */}
      <div className="absolute inset-0">
        {/* Base black background */}
        <div className="absolute inset-0 bg-black">
          {/* Purple animated waves */}
          <div className="absolute inset-0">
            <motion.div
              className="absolute w-full h-full"
              style={{
                background: `
                  radial-gradient(circle at 20% 30%, rgba(147, 51, 234, 0.3) 0%, transparent 50%),
                  radial-gradient(circle at 80% 70%, rgba(168, 85, 247, 0.2) 0%, transparent 50%),
                  radial-gradient(circle at 40% 80%, rgba(124, 58, 237, 0.4) 0%, transparent 50%)
                `
              }}
              animate={{
                opacity: [0.3, 0.8, 0.3],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 10,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </div>

          {/* Floating purple particles */}
          <div className="absolute inset-0">
            {[...Array(60)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-purple-400 rounded-full"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
                animate={{
                  y: [0, -120, 0],
                  x: [0, Math.random() * 60 - 30, 0],
                  opacity: [0, 1, 0],
                  scale: [0, 2, 0],
                }}
                transition={{
                  duration: 8 + Math.random() * 4,
                  repeat: Infinity,
                  delay: Math.random() * 4,
                }}
              />
            ))}
          </div>

          {/* Purple gradient orbs */}
          <div className="absolute inset-0">
            <motion.div
              className="absolute w-96 h-96 bg-gradient-to-r from-purple-600/30 to-purple-400/30 rounded-full blur-3xl"
              animate={{
                x: [0, 300, -150, 0],
                y: [0, -200, 150, 0],
                scale: [1, 1.5, 0.8, 1],
              }}
              transition={{
                duration: 25,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              style={{ left: '10%', top: '20%' }}
            />
            <motion.div
              className="absolute w-80 h-80 bg-gradient-to-r from-purple-500/40 to-purple-700/40 rounded-full blur-3xl"
              animate={{
                x: [0, -200, 100, 0],
                y: [0, 150, -80, 0],
                scale: [1, 0.6, 1.6, 1],
              }}
              transition={{
                duration: 18,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 4,
              }}
              style={{ right: '15%', top: '40%' }}
            />
          </div>

          {/* Purple streaks */}
          <div className="absolute inset-0">
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent"
                style={{
                  width: `${200 + Math.random() * 300}px`,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  transform: `rotate(${Math.random() * 360}deg)`,
                }}
                animate={{
                  opacity: [0, 0.8, 0],
                  scaleX: [0, 1, 0],
                }}
                transition={{
                  duration: 3 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 5,
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Header */}
      <motion.header 
        className="relative z-10 px-6 py-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <nav className="max-w-7xl mx-auto flex items-center justify-between">
          <motion.div 
            className="flex items-center space-x-2"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-purple-400 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-purple-200 bg-clip-text text-transparent">
              Spectra AI
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <motion.div 
            className="hidden md:flex items-center space-x-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            {navigationItems.map((item, index) => (
              <motion.a
                key={index}
                href={item.href}
                className="text-purple-200 hover:text-white transition-colors font-medium"
                whileHover={{ scale: 1.05 }}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
              >
                {item.label}
              </motion.a>
            ))}
            
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-white/10 backdrop-blur-sm hover:bg-white/20 transition-colors text-white"
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            
            {isAuthenticated ? (
              <motion.button
                onClick={() => navigate('/dashboard')}
                className="px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-400 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Dashboard
              </motion.button>
            ) : (
              <div className="flex items-center space-x-4">
                <motion.button
                  onClick={() => openAuthModal('signin')}
                  className="px-4 py-2 text-white/80 hover:text-white transition-colors"
                  whileHover={{ scale: 1.05 }}
                >
                  Sign In
                </motion.button>
                <motion.button
                  onClick={() => openAuthModal('signup')}
                  className="px-6 py-2 bg-gradient-to-r from-purple-600 to-purple-400 text-white rounded-lg hover:shadow-lg transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Sign Up
                </motion.button>
              </div>
            )}
          </motion.div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-lg bg-white/10 backdrop-blur-sm text-white"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </nav>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden mt-4 p-4 bg-black/40 backdrop-blur-sm rounded-lg border border-purple-500/20"
          >
            <div className="flex flex-col space-y-4">
              {navigationItems.map((item, index) => (
                <a
                  key={index}
                  href={item.href}
                  className="text-purple-200 hover:text-white transition-colors font-medium"
                >
                  {item.label}
                </a>
              ))}
              <button
                onClick={toggleTheme}
                className="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/10 text-white"
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                <span>Toggle Theme</span>
              </button>
              {isAuthenticated ? (
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-400 text-white rounded-lg"
                >
                  Dashboard
                </button>
              ) : (
                <>
                  <button
                    onClick={() => openAuthModal('signin')}
                    className="px-4 py-2 text-left hover:bg-white/10 rounded-lg text-white"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => openAuthModal('signup')}
                    className="px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-400 text-white rounded-lg"
                  >
                    Sign Up
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </motion.header>

      {/* Hero Section */}
      <main className="relative z-10 px-6 py-20">
        <div className="max-w-7xl mx-auto text-center">
          <motion.h1
            className="text-5xl md:text-7xl font-bold mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            <motion.span 
              className="bg-gradient-to-r from-purple-400 via-purple-300 to-purple-200 bg-clip-text text-transparent"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.5, delay: 0.8 }}
            >
              Transform Data
            </motion.span>
            <br />
            <motion.span 
              className="text-white"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.5, delay: 1.2 }}
            >
              Into Intelligence
            </motion.span>
          </motion.h1>

          <motion.p
            className="text-xl md:text-2xl text-purple-200 mb-8 max-w-4xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.5 }}
          >
            Spectra is the first 3D visual tool that turns unstructured data into structured gold — 
            train custom AI models, generate production-ready code from sketches, and build no-code APIs with just flowcharts.
          </motion.p>

          <motion.p
            className="text-lg text-purple-300 mb-12 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.8 }}
          >
            Visual 3D tool for reshaping unstructured data (text/audio/image) into structured datasets 
            to train custom AI models like DALL·E, LLaMA. Create APIs with drag-and-drop simplicity.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center mb-20"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 2.1 }}
          >
            <motion.button
              onClick={() => isAuthenticated ? navigate('/dashboard') : openAuthModal('signup')}
              className="group px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-400 text-white rounded-xl font-semibold hover:shadow-2xl transition-all duration-300 flex items-center justify-center space-x-2"
              whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(147, 51, 234, 0.4)" }}
              whileTap={{ scale: 0.95 }}
            >
              <span>Get Started Free</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>

          {/* Dashboard Previews */}
          <motion.div
            className="grid md:grid-cols-3 gap-8 mb-20"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 2.4 }}
          >
            {dashboardPreviews.map((preview, index) => (
              <motion.div
                key={index}
                className="group relative overflow-hidden rounded-2xl bg-black/40 backdrop-blur-sm border border-purple-500/30 hover:border-purple-500/60 transition-all duration-500"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 2.6 + index * 0.2 }}
                whileHover={{ y: -10, scale: 1.02 }}
              >
                <div className="aspect-video overflow-hidden">
                  <motion.img
                    src={preview.image}
                    alt={preview.title}
                    className="w-full h-full object-cover"
                    whileHover={{ scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  />
                </div>
                <motion.div 
                  className="p-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 2.8 + index * 0.2 }}
                >
                  <h3 className="text-xl font-semibold mb-2 text-white">
                    {preview.title}
                  </h3>
                  <p className="text-purple-200">
                    {preview.description}
                  </p>
                </motion.div>
              </motion.div>
            ))}
          </motion.div>

          {/* User Types */}
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 3.2 }}
          >
            {userTypes.map((userType, index) => (
              <motion.div
                key={index}
                className="p-6 bg-black/40 backdrop-blur-sm rounded-2xl border border-purple-500/30 hover:border-purple-500/60 transition-all duration-500 group"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 3.4 + index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
              >
                <motion.div 
                  className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-400 rounded-lg flex items-center justify-center mb-4 text-white"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  {userType.icon}
                </motion.div>
                <h3 className="text-lg font-semibold mb-2 text-white">
                  {userType.title}
                </h3>
                <p className="text-purple-200 text-sm">
                  {userType.description}
                </p>
              </motion.div>
            ))}
          </motion.div>

          {/* Features Grid */}
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 4 }}
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="p-6 bg-black/40 backdrop-blur-sm rounded-2xl border border-purple-500/30 hover:border-purple-500/60 transition-all duration-500 group"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 4.2 + index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
              >
                <motion.div 
                  className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-400 rounded-xl flex items-center justify-center mb-4 text-white"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                >
                  {feature.icon}
                </motion.div>
                <h3 className="text-xl font-semibold mb-2 text-white">
                  {feature.title}
                </h3>
                <p className="text-purple-200">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </motion.div>

          {/* CTA Section */}
          <motion.div
            className="bg-gradient-to-r from-purple-600/30 to-purple-400/30 rounded-3xl p-12 backdrop-blur-sm border border-purple-500/40"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 4.8 }}
            whileHover={{ scale: 1.02 }}
          >
            <motion.h2 
              className="text-3xl font-bold mb-4 text-white"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 5 }}
            >
              Ready to Transform Your Data?
            </motion.h2>
            <motion.p 
              className="text-xl text-purple-200 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 5.2 }}
            >
              Join thousands of developers and data scientists using Spectra AI
            </motion.p>
            <motion.button
              onClick={() => isAuthenticated ? navigate('/dashboard') : openAuthModal('signup')}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-400 text-white rounded-xl font-semibold hover:shadow-2xl transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 5.4 }}
              whileHover={{ scale: 1.05, boxShadow: "0 20px 40px rgba(147, 51, 234, 0.4)" }}
              whileTap={{ scale: 0.95 }}
            >
              Start Building Now
            </motion.button>
          </motion.div>
        </div>
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        mode={authMode}
        onSwitchMode={() => setAuthMode(authMode === 'signin' ? 'signup' : 'signin')}
      />
    </div>
  );
};

export default LandingPage;