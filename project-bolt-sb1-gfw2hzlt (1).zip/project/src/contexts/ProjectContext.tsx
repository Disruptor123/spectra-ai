import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

export interface Project {
  id: string;
  name: string;
  description: string;
  type: 'dataset' | 'api' | 'code';
  status: 'active' | 'deployed' | 'processing' | 'draft';
  progress: number;
  lastUpdated: string;
  color: string;
  data?: any;
  createdAt: string;
}

export interface Dataset {
  id: string;
  name: string;
  type: 'image' | 'text' | 'audio' | 'json' | 'csv';
  size: string;
  data: any;
  processed: boolean;
  createdAt: string;
}

export interface API {
  id: string;
  name: string;
  endpoint: string;
  method: string;
  deployed: boolean;
  createdAt: string;
  config: any;
}

export interface Activity {
  id: string;
  action: string;
  item: string;
  projectId?: string;
  createdAt: string;
}

interface ProjectContextType {
  projects: Project[];
  datasets: Dataset[];
  apis: API[];
  activities: Activity[];
  stats: {
    projectsCreated: number;
    datasetsProcessed: number;
    apisDeployed: number;
    modelAccuracy: number;
  };
  addProject: (project: Omit<Project, 'id' | 'createdAt'>) => Promise<void>;
  updateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  addDataset: (dataset: Omit<Dataset, 'id' | 'createdAt'>) => Promise<void>;
  addAPI: (api: Omit<API, 'id' | 'createdAt'>) => Promise<void>;
  addActivity: (activity: Omit<Activity, 'id' | 'createdAt'>) => Promise<void>;
  loadUserData: () => Promise<void>;
  isLoading: boolean;
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export const ProjectProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [apis, setApis] = useState<API[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [stats, setStats] = useState({
    projectsCreated: 0,
    datasetsProcessed: 0,
    apisDeployed: 0,
    modelAccuracy: 0
  });

  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      // Clear data when user logs out
      setProjects([]);
      setDatasets([]);
      setApis([]);
      setActivities([]);
      setStats({
        projectsCreated: 0,
        datasetsProcessed: 0,
        apisDeployed: 0,
        modelAccuracy: 0
      });
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      // Load projects
      const { data: projectsData } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (projectsData) {
        const formattedProjects = projectsData.map(p => ({
          id: p.id,
          name: p.name,
          description: p.description,
          type: p.type as 'dataset' | 'api' | 'code',
          status: p.status as 'active' | 'deployed' | 'processing' | 'draft',
          progress: p.progress,
          lastUpdated: new Date(p.updated_at).toLocaleDateString(),
          color: getProjectColor(p.type),
          data: p.data,
          createdAt: p.created_at
        }));
        setProjects(formattedProjects);
      }

      // Load datasets
      const { data: datasetsData } = await supabase
        .from('datasets')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (datasetsData) {
        const formattedDatasets = datasetsData.map(d => ({
          id: d.id,
          name: d.name,
          type: d.type as 'image' | 'text' | 'audio' | 'json' | 'csv',
          size: d.size,
          data: d.data,
          processed: d.processed,
          createdAt: d.created_at
        }));
        setDatasets(formattedDatasets);
      }

      // Load APIs
      const { data: apisData } = await supabase
        .from('apis')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (apisData) {
        const formattedApis = apisData.map(a => ({
          id: a.id,
          name: a.name,
          endpoint: a.endpoint,
          method: a.method,
          deployed: a.deployed,
          createdAt: a.created_at,
          config: a.config
        }));
        setApis(formattedApis);
      }

      // Load activities
      const { data: activitiesData } = await supabase
        .from('activities')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (activitiesData) {
        const formattedActivities = activitiesData.map(a => ({
          id: a.id,
          action: a.action,
          item: a.item,
          projectId: a.project_id,
          createdAt: a.created_at
        }));
        setActivities(formattedActivities);
      }

      // Update stats
      updateStats(projectsData?.length || 0, datasetsData?.filter(d => d.processed).length || 0, apisData?.filter(a => a.deployed).length || 0);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getProjectColor = (type: string) => {
    switch (type) {
      case 'dataset': return 'from-green-500 to-emerald-500';
      case 'api': return 'from-blue-500 to-cyan-500';
      case 'code': return 'from-purple-500 to-pink-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const updateStats = (projectsCount: number, datasetsCount: number, apisCount: number) => {
    setStats({
      projectsCreated: projectsCount,
      datasetsProcessed: datasetsCount,
      apisDeployed: apisCount,
      modelAccuracy: apisCount > 0 ? Math.round(85 + Math.random() * 10) : 0
    });
  };

  const addProject = async (project: Omit<Project, 'id' | 'createdAt'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('projects')
        .insert({
          user_id: user.id,
          name: project.name,
          description: project.description,
          type: project.type,
          status: project.status,
          progress: project.progress,
          data: project.data
        })
        .select()
        .single();

      if (error) throw error;

      const newProject: Project = {
        id: data.id,
        name: data.name,
        description: data.description,
        type: data.type,
        status: data.status,
        progress: data.progress,
        lastUpdated: 'Just now',
        color: getProjectColor(data.type),
        data: data.data,
        createdAt: data.created_at
      };

      setProjects(prev => [newProject, ...prev]);
      
      // Add activity
      await addActivity({
        action: 'Created project',
        item: project.name,
        projectId: data.id
      });

      // Update stats
      setStats(prev => ({
        ...prev,
        projectsCreated: prev.projectsCreated + 1
      }));
    } catch (error) {
      console.error('Error adding project:', error);
    }
  };

  const updateProject = async (id: string, updates: Partial<Project>) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('projects')
        .update({
          name: updates.name,
          description: updates.description,
          status: updates.status,
          progress: updates.progress,
          data: updates.data,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      setProjects(prev => 
        prev.map(project => 
          project.id === id 
            ? { ...project, ...updates, lastUpdated: 'Just now' }
            : project
        )
      );
    } catch (error) {
      console.error('Error updating project:', error);
    }
  };

  const deleteProject = async (id: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('projects')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      setProjects(prev => prev.filter(project => project.id !== id));
      
      // Update stats
      setStats(prev => ({
        ...prev,
        projectsCreated: Math.max(0, prev.projectsCreated - 1)
      }));
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  const addDataset = async (dataset: Omit<Dataset, 'id' | 'createdAt'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('datasets')
        .insert({
          user_id: user.id,
          name: dataset.name,
          type: dataset.type,
          size: dataset.size,
          data: dataset.data,
          processed: dataset.processed
        })
        .select()
        .single();

      if (error) throw error;

      const newDataset: Dataset = {
        id: data.id,
        name: data.name,
        type: data.type,
        size: data.size,
        data: data.data,
        processed: data.processed,
        createdAt: data.created_at
      };

      setDatasets(prev => [newDataset, ...prev]);

      if (dataset.processed) {
        setStats(prev => ({
          ...prev,
          datasetsProcessed: prev.datasetsProcessed + 1
        }));
      }
    } catch (error) {
      console.error('Error adding dataset:', error);
    }
  };

  const addAPI = async (api: Omit<API, 'id' | 'createdAt'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('apis')
        .insert({
          user_id: user.id,
          name: api.name,
          endpoint: api.endpoint,
          method: api.method,
          deployed: api.deployed,
          config: api.config
        })
        .select()
        .single();

      if (error) throw error;

      const newAPI: API = {
        id: data.id,
        name: data.name,
        endpoint: data.endpoint,
        method: data.method,
        deployed: data.deployed,
        createdAt: data.created_at,
        config: data.config
      };

      setApis(prev => [newAPI, ...prev]);

      if (api.deployed) {
        setStats(prev => ({
          ...prev,
          apisDeployed: prev.apisDeployed + 1
        }));
      }
    } catch (error) {
      console.error('Error adding API:', error);
    }
  };

  const addActivity = async (activity: Omit<Activity, 'id' | 'createdAt'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('activities')
        .insert({
          user_id: user.id,
          action: activity.action,
          item: activity.item,
          project_id: activity.projectId
        })
        .select()
        .single();

      if (error) throw error;

      const newActivity: Activity = {
        id: data.id,
        action: data.action,
        item: data.item,
        projectId: data.project_id,
        createdAt: data.created_at
      };

      setActivities(prev => [newActivity, ...prev.slice(0, 9)]);
    } catch (error) {
      console.error('Error adding activity:', error);
    }
  };

  return (
    <ProjectContext.Provider value={{
      projects,
      datasets,
      apis,
      activities,
      stats,
      addProject,
      updateProject,
      deleteProject,
      addDataset,
      addAPI,
      addActivity,
      loadUserData,
      isLoading
    }}>
      {children}
    </ProjectContext.Provider>
  );
};

export const useProject = () => {
  const context = useContext(ProjectContext);
  if (context === undefined) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
};