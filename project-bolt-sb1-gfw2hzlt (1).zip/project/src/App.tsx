import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import DatasetTransformer from './components/DatasetTransformer';
import APIDesigner from './components/APIDesigner';
import CodeBuilder from './components/CodeBuilder';
import Settings from './components/Settings';
import Profile from './components/Profile';
import Help from './components/Help';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider } from './contexts/AuthContext';
import { ProjectProvider } from './contexts/ProjectContext';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ProjectProvider>
          <Router>
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
              <Routes>
                <Route path="/" element={<LandingPage />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/datasets" element={<DatasetTransformer />} />
                <Route path="/api-designer" element={<APIDesigner />} />
                <Route path="/code-builder" element={<CodeBuilder />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/help" element={<Help />} />
              </Routes>
            </div>
          </Router>
        </ProjectProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;